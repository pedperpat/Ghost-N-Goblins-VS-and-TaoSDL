﻿using System;

namespace DamGame
{
    class EditMode : Game
    {
        public EditMode() :base()
        {

        }
    }
}
